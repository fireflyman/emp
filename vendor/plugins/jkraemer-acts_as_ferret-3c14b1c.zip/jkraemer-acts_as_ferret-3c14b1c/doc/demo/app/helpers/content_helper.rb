module ContentHelper
end
