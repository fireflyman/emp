class SpecialContent < ContentBase

end
