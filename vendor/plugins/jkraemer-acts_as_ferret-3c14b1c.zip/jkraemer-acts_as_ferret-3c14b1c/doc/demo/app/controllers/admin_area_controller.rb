class AdminAreaController < ApplicationController

end

